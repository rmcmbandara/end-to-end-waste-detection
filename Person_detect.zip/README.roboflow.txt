
Person_detect_13_3_2022 - v2 2022-03-13 8:08pm
==============================

This dataset was exported via roboflow.ai on March 13, 2022 at 1:09 PM GMT

It includes 1962 images.
Person are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


